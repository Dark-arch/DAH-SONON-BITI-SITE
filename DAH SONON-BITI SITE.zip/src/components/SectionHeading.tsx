import type { ReactNode } from "react";

interface SectionHeadingProps {
  kicker: string;
  title: ReactNode;
  description?: string;
  align?: "left" | "center";
  dark?: boolean;
  className?: string;
}

export default function SectionHeading({
  kicker,
  title,
  description,
  align = "center",
  dark = false,
  className = "",
}: SectionHeadingProps) {
  const centered = align === "center";
  return (
    <div className={`${centered ? "mx-auto max-w-3xl text-center" : "max-w-3xl"} ${className}`}>
      <span data-reveal className="kicker">
        {centered && <span className="h-px w-7 bg-rouge/50" aria-hidden="true" />}
        {kicker}
        <span className="h-px w-7 bg-rouge/50" aria-hidden="true" />
      </span>
      <h2
        data-reveal
        data-delay="0.08"
        className={`mt-5 text-[1.75rem] leading-[1.12] md:text-[2.6rem] font-bold tracking-tight ${
          dark ? "text-blanc" : "text-noir"
        }`}
      >
        {title}
      </h2>
      {description && (
        <p
          data-reveal
          data-delay="0.16"
          className={`mt-5 text-base md:text-lg leading-relaxed ${
            dark ? "text-blanc/60" : "text-neutral-500"
          }`}
        >
          {description}
        </p>
      )}
    </div>
  );
}
