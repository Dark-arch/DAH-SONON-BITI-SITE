import { useLocation } from "react-router-dom";
import WhatsAppIcon, { WHATSAPP_URL } from "./WhatsAppIcon";

export default function FloatingWhatsApp() {
  const { pathname } = useLocation();
  const onContact = pathname === "/contact";

  return (
    <a
      href={WHATSAPP_URL}
      target="_blank"
      rel="noreferrer"
      aria-label="Discuter sur WhatsApp"
      className={`group fixed right-5 z-[60] flex h-13 w-13 items-center justify-center rounded-full bg-rouge text-blanc shadow-[0_14px_38px_-8px_rgba(176,31,36,0.65)] transition-all duration-300 hover:bg-rouge-fonce md:right-7 md:h-15 md:w-15 ${
        onContact ? "bottom-24 md:bottom-7" : "bottom-5 md:bottom-7"
      }`}
    >
      <span className="animate-pulse-soft flex items-center justify-center">
        <WhatsAppIcon className="h-6 w-6 md:h-7 md:w-7" />
      </span>
      <span className="pointer-events-none absolute right-full mr-4 hidden whitespace-nowrap rounded-lg bg-noir px-3.5 py-2 text-xs font-medium text-blanc opacity-0 transition-opacity duration-300 group-hover:opacity-100 md:block">
        Discuter sur WhatsApp
      </span>
    </a>
  );
}
