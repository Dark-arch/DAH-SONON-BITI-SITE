interface BuffaloMarkProps {
  className?: string;
  /** Color of the red forehead diamond / accent marks */
  accent?: string;
  /** Show the surrounding thin circle */
  withRing?: boolean;
  title?: string;
}

/**
 * Emblème — tête de buffle stylisée dans un cercle fin.
 * Géométrie épurée, cornes larges et symétriques, aucun détail réaliste.
 */
export default function BuffaloMark({
  className = "w-10 h-10",
  accent = "#B01F24",
  withRing = true,
  title,
}: BuffaloMarkProps) {
  return (
    <svg
      viewBox="0 0 64 64"
      className={className}
      fill="none"
      role={title ? "img" : "presentation"}
      aria-label={title}
      aria-hidden={title ? undefined : true}
    >
      {withRing && (
        <circle cx="32" cy="32" r="30.5" stroke="currentColor" strokeWidth="2" />
      )}
      <g fill="currentColor">
        <path d="M25.2 22.4 C18.6 20.6 12.8 16 10 9.4 C9.7 8.6 10.5 7.9 11.3 8.3 C17.4 13.8 22.6 16.6 26.8 17.8 Z" />
        <path d="M38.8 22.4 C45.4 20.6 51.2 16 54 9.4 C54.3 8.6 53.5 7.9 52.7 8.3 C46.6 13.8 41.4 16.6 37.2 17.8 Z" />
        <path d="M24.6 21.5 L18.6 20 L23.4 26.2 Z" />
        <path d="M39.4 21.5 L45.4 20 L40.6 26.2 Z" />
        <path d="M25 17.5 C23.8 24.8 25.3 31.8 29 37.6 L30.9 42.3 C31.3 43.3 32.7 43.3 33.1 42.3 L35 37.6 C38.7 31.8 40.2 24.8 39 17.5 Z" />
        <rect x="27.8" y="43.2" width="8.4" height="5.6" rx="2.4" />
      </g>
      <path d="M32 24.5 L34.4 29.2 L32 33.9 L29.6 29.2 Z" fill={accent} />
    </svg>
  );
}
