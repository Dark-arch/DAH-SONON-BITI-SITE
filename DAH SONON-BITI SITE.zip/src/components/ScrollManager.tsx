import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useLenis } from "../context/LenisContext";
import { ScrollTrigger } from "../lib/gsap";

export default function ScrollManager() {
  const { pathname, hash } = useLocation();
  const lenis = useLenis();

  useEffect(() => {
    if (hash) {
      const timer = setTimeout(() => {
        const el = document.querySelector(hash) as HTMLElement | null;
        if (el) {
          if (lenis) lenis.scrollTo(el, { offset: -84, duration: 1.4 });
          else el.scrollIntoView({ behavior: "smooth" });
        }
      }, 350);
      return () => clearTimeout(timer);
    }
    if (lenis) lenis.scrollTo(0, { immediate: true });
    else window.scrollTo(0, 0);
    const raf = requestAnimationFrame(() => ScrollTrigger.refresh());
    return () => cancelAnimationFrame(raf);
  }, [pathname, hash, lenis]);

  return null;
}
