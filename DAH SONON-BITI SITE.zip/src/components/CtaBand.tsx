import { Link } from "react-router-dom";
import { Calendar } from "lucide-react";
import AfricanPattern from "./AfricanPattern";
import WhatsAppIcon, { WHATSAPP_URL } from "./WhatsAppIcon";

interface CtaBandProps {
  title: string;
  text: string;
  secondaryLabel?: string;
  secondaryTo?: string;
}

/** Bandeau CTA final — fond noir, motif géométrique en filigrane, accent rouge */
export default function CtaBand({
  title,
  text,
  secondaryLabel = "Réserver une Consultation Formelle",
  secondaryTo = "/contact",
}: CtaBandProps) {
  return (
    <section className="relative overflow-hidden bg-noir py-24 md:py-32">
      <AfricanPattern className="absolute inset-0 h-full w-full text-blanc opacity-[0.06]" />
      <div className="absolute left-1/2 top-0 h-px w-2/3 -translate-x-1/2 bg-gradient-to-r from-transparent via-rouge/60 to-transparent" />
      <div className="container-site relative text-center">
        <h2
          data-reveal
          className="mx-auto max-w-3xl text-3xl font-bold leading-[1.1] tracking-tight text-blanc md:text-5xl"
        >
          {title}
        </h2>
        <p data-reveal data-delay="0.1" className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-blanc/60 md:text-lg">
          {text}
        </p>
        <div data-reveal data-delay="0.2" className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="btn-primary">
            <WhatsAppIcon className="h-4.5 w-4.5" />
            Discuter Maintenant sur WhatsApp
          </a>
          <Link to={secondaryTo} className="btn-outline-light">
            <Calendar className="h-4.5 w-4.5" />
            {secondaryLabel}
          </Link>
        </div>
      </div>
    </section>
  );
}
