import type { ReactNode } from "react";
import AfricanPattern from "./AfricanPattern";

interface PageHeroProps {
  kicker: string;
  title: ReactNode;
  epigraph?: string;
  subtitle?: string;
}

/** Bandeau d'ouverture sombre des pages intérieures */
export default function PageHero({ kicker, title, epigraph, subtitle }: PageHeroProps) {
  return (
    <section className="relative overflow-hidden bg-noir pb-24 pt-40 md:pb-32 md:pt-52">
      <AfricanPattern className="absolute inset-0 h-full w-full text-blanc opacity-[0.045]" />
      <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-noir to-transparent" />
      <div className="container-site relative">
        <span data-hero="0" className="kicker">
          {kicker}
          <span className="h-px w-10 bg-rouge/60" aria-hidden="true" />
        </span>
        <h1
          data-hero="0.15"
          className="mt-6 max-w-4xl text-4xl font-bold leading-[1.06] tracking-tight text-blanc sm:text-5xl lg:text-6xl"
        >
          {title}
        </h1>
        {epigraph && (
          <p data-hero="0.3" className="mt-5 text-lg font-semibold text-rouge md:text-xl">
            {epigraph}
          </p>
        )}
        {subtitle && (
          <p data-hero="0.4" className="mt-6 max-w-2xl text-base leading-relaxed text-blanc/60 md:text-lg">
            {subtitle}
          </p>
        )}
      </div>
    </section>
  );
}
