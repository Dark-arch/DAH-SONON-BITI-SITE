import { useCallback, useEffect } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { useLenis } from "../context/LenisContext";

interface LightboxProps {
  images: string[];
  index: number | null;
  onClose: () => void;
  onNavigate: (nextIndex: number) => void;
}

export default function Lightbox({ images, index, onClose, onNavigate }: LightboxProps) {
  const lenis = useLenis();
  const isOpen = index !== null;

  const prev = useCallback(() => {
    if (index === null) return;
    onNavigate((index - 1 + images.length) % images.length);
  }, [index, images.length, onNavigate]);

  const next = useCallback(() => {
    if (index === null) return;
    onNavigate((index + 1) % images.length);
  }, [index, images.length, onNavigate]);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isOpen, onClose, prev, next]);

  useEffect(() => {
    if (isOpen) {
      lenis?.stop();
      document.documentElement.style.overflow = "hidden";
    } else {
      lenis?.start();
      document.documentElement.style.overflow = "";
    }
    return () => {
      lenis?.start();
      document.documentElement.style.overflow = "";
    };
  }, [isOpen, lenis]);

  if (index === null) return null;

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-noir/95 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Galerie en plein écran"
    >
      <button
        onClick={onClose}
        className="absolute right-5 top-5 z-10 flex h-12 w-12 items-center justify-center rounded-full border border-blanc/20 text-blanc transition-colors hover:border-rouge hover:bg-rouge"
        aria-label="Fermer"
      >
        <X className="h-5 w-5" />
      </button>

      <button
        onClick={(e) => {
          e.stopPropagation();
          prev();
        }}
        className="absolute left-3 top-1/2 z-10 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-blanc/20 text-blanc transition-colors hover:border-rouge hover:bg-rouge md:left-8"
        aria-label="Image précédente"
      >
        <ChevronLeft className="h-6 w-6" />
      </button>

      <figure className="flex max-h-full flex-col items-center px-14 md:px-24" onClick={(e) => e.stopPropagation()}>
        <img
          src={images[index].replace("w_600", "w_1080")}
          alt={`Dah Sonon-Biti dans l'exercice de sa mission — photo ${index + 1}`}
          className="max-h-[80vh] w-auto max-w-full rounded-xl object-contain shadow-2xl"
        />
        <figcaption className="mt-5 text-xs font-medium uppercase tracking-[0.28em] text-blanc/50">
          {index + 1} / {images.length}
        </figcaption>
      </figure>

      <button
        onClick={(e) => {
          e.stopPropagation();
          next();
        }}
        className="absolute right-3 top-1/2 z-10 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-blanc/20 text-blanc transition-colors hover:border-rouge hover:bg-rouge md:right-8"
        aria-label="Image suivante"
      >
        <ChevronRight className="h-6 w-6" />
      </button>
    </div>
  );
}
