import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

interface InfoCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  linkText?: string;
  linkTo?: string;
  delay?: number;
  /** light = fond blanc (section grise) · tinted = fond gris très clair (section blanche) */
  tone?: "light" | "tinted";
}

/**
 * Système de cartes unique (référence 1.4bis) :
 * fond clair, rounded-2xl, ombre douce, bloc icône carré arrondi en haut,
 * titre SemiBold mt-5, description Regular mt-2, padding généreux, hover -4px.
 */
export default function InfoCard({
  icon,
  title,
  description,
  linkText,
  linkTo,
  delay = 0,
}: InfoCardProps) {
  return (
    <div
      data-reveal
      data-delay={String(delay)}
      className="group card-premium flex flex-col items-start"
    >
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-rouge/5 text-rouge transition-colors group-hover:bg-rouge group-hover:text-blanc">
        {icon}
      </div>
      <h3 className="mt-6 text-[18px] md:text-[20px] font-bold tracking-tight text-noir leading-tight">
        {title}
      </h3>
      <p className="mt-4 text-[15px] leading-relaxed text-neutral-500 flex-1">
        {description}
      </p>
      {linkText && linkTo && (
        <Link
          to={linkTo}
          className="mt-8 flex items-center gap-2 text-[13px] font-bold text-rouge uppercase tracking-widest hover:translate-x-1 transition-transform"
        >
          {linkText}
          <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      )}
    </div>
  );
}
