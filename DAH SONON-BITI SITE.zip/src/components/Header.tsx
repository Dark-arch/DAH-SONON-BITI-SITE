import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import WhatsAppIcon, { WHATSAPP_URL } from "./WhatsAppIcon";
import { useLenis } from "../context/LenisContext";

const NAV_ITEMS = [
  { label: "Accueil", to: "/" },
  { label: "Biographie", to: "/biographie" },
  { label: "Mission & Vision", to: "/mission-vision" },
  { label: "Domaines", to: "/domaines" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const lenis = useLenis();
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname, location.hash]);

  useEffect(() => {
    if (open) {
      lenis?.stop();
      document.documentElement.style.overflow = "hidden";
    } else {
      lenis?.start();
      document.documentElement.style.overflow = "";
    }
    return () => {
      lenis?.start();
      document.documentElement.style.overflow = "";
    };
  }, [open, lenis]);

  const dark = !scrolled && !open;

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 border-b ${
          scrolled && !open
            ? "bg-blanc/95 text-noir border-neutral-100 backdrop-blur-xl shadow-sm"
            : "bg-transparent text-blanc border-transparent"
        }`}
      >
        <div className="container-site flex h-[80px] items-center justify-between gap-6">
          <Link to="/" className="flex items-center gap-3 shrink-0" aria-label="Accueil — Dah Sonon-Biti">
            <img 
              src="https://res.cloudinary.com/rqaqbeay/image/upload/v1791084606/images_5.png" 
              alt="Logo Dah Sonon-Biti"
              className="h-9 w-9 md:h-11 md:w-11 object-contain"
            />
            <span className="text-[14px] md:text-base font-bold tracking-tight uppercase">
              Dah SONON-BITI
            </span>
          </Link>

          <nav className="hidden lg:flex flex-1 items-center justify-center gap-6 xl:gap-9" aria-label="Navigation principale">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                className={({ isActive }) =>
                  `text-[13px] font-bold tracking-wide transition-colors duration-300 ${
                    isActive
                      ? "text-rouge"
                      : `${dark ? "text-blanc/90 hover:text-blanc" : "text-noir/70 hover:text-noir"}`
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <Link
              to="/#temoignages"
              className={`text-[13px] font-bold tracking-wide transition-colors duration-300 ${
                dark ? "text-blanc/90 hover:text-blanc" : "text-noir/70 hover:text-noir"
              }`}
            >
              Témoignages
            </Link>
            <NavLink
              to="/contact"
              className={({ isActive }) =>
                `text-[13px] font-bold tracking-wide transition-colors duration-300 ${
                  isActive
                    ? "text-rouge"
                    : `${dark ? "text-blanc/90 hover:text-blanc" : "text-noir/70 hover:text-noir"}`
                }`
              }
            >
              Contact
            </NavLink>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noreferrer"
              className="hidden md:inline-flex items-center gap-2.5 rounded-lg bg-rouge px-5 py-2.5 text-[13px] font-bold text-blanc transition-all duration-300 hover:bg-rouge-fonce shadow-sm"
            >
              Consulter sur WhatsApp
              <WhatsAppIcon className="h-4 w-4" />
            </a>
            <button
              onClick={() => setOpen(!open)}
              className="lg:hidden flex h-10 w-10 items-center justify-center rounded-lg border border-current/20"
              aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Menu mobile */}
      <div
        className={`fixed inset-0 z-40 bg-noir text-blanc transition-all duration-500 lg:hidden ${
          open ? "visible opacity-100" : "invisible opacity-0"
        }`}
      >
        <div className="container-site flex h-full flex-col justify-center pt-16 pb-10">
          <nav className="flex flex-col gap-6" aria-label="Navigation mobile">
            {NAV_ITEMS.concat([
              { label: "Témoignages", to: "/#temoignages" },
              { label: "Contact", to: "/contact" },
            ]).map((item) => (
              <Link
                key={item.to + item.label}
                to={item.to}
                className="text-3xl font-bold tracking-tight transition-colors hover:text-rouge"
                onClick={() => setOpen(false)}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noreferrer"
            className="btn-primary mt-12 self-start"
          >
            Consulter sur WhatsApp
            <WhatsAppIcon className="h-4.5 w-4.5" />
          </a>
        </div>
      </div>
    </>
  );
}
