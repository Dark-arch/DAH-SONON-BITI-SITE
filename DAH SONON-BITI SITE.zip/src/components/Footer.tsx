import { Link } from "react-router-dom";

const QUICK_LINKS = [
  { label: "Accueil", to: "/" },
  { label: "Biographie", to: "/biographie" },
  { label: "Mission & Vision", to: "/mission-vision" },
  { label: "Domaines d’intervention", to: "/domaines" },
  { label: "Témoignages", to: "/#temoignages" },
  { label: "Contact & Rendez-vous", to: "/contact" },
];

export default function Footer() {
  return (
    <footer className="bg-noir text-blanc">
      <div className="container-site grid gap-12 py-20 md:grid-cols-3">
        {/* Colonne 1 — Identité */}
        <div>
          <p className="text-sm font-semibold leading-relaxed">
            Sa Majesté Dah SONON-BITI « Le Buffle » — dit « AGBOGBÉTON ». Prêtre de Fâ Oroumila, Grand Maître Spirituel, Guérisseur Traditionnel et Président-Fondateur de l'ONG Savoir Vivre Bénin. La force de la tradition pour éclairer le monde moderne.
          </p>
        </div>

        {/* Colonne 2 — Liens rapides */}
        <div className="md:px-12">
          <ul className="space-y-3">
            {QUICK_LINKS.map((link) => (
              <li key={link.to + link.label}>
                <Link
                  to={link.to}
                  className="text-[15px] font-bold transition-colors duration-300 hover:text-rouge"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Colonne 3 — Contact rapide */}
        <div>
          <p className="text-[15px] leading-relaxed">
            Abomey-Calavi, Bénin — BP 2757. Téléphone : <br />
            +229 66 41 11 16 / +229 95 05 64 72. <br />
            Email : <a href="mailto:dahsononbiti@gmail.com" className="hover:text-rouge underline">dahsononbiti@gmail.com</a>. <br />
            Lundi–samedi, 8h–20h (GMT+1).
          </p>
        </div>
      </div>

      <div className="border-t border-blanc/10">
        <div className="container-site flex flex-col items-center justify-between gap-4 py-7 text-[12.5px] text-blanc/40 md:flex-row">
          <p>© 2026 Sa Majesté Dah SONON-BITI « Le Buffle » — Tous droits réservés.</p>
          <div className="flex flex-wrap items-center justify-center gap-x-7 gap-y-2">
            <a href="#" onClick={(e) => e.preventDefault()} className="transition-colors hover:text-rouge">
              Mentions légales
            </a>
            <a href="#" onClick={(e) => e.preventDefault()} className="transition-colors hover:text-rouge">
              Politique de confidentialité
            </a>
            <a href="#" onClick={(e) => e.preventDefault()} className="transition-colors hover:text-rouge">
              Conditions générales
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
