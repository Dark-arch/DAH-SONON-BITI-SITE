/**
 * Motif géométrique africain en filigrane —
 * chevrons et losanges, pensé pour être utilisé en très faible opacité (currentColor).
 */
export default function AfricanPattern({ className = "" }: { className?: string }) {
  return (
    <svg
      className={className}
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <pattern id="motif-africain" width="112" height="112" patternUnits="userSpaceOnUse">
          <path d="M0 112 L56 56 L112 112" stroke="currentColor" fill="none" strokeWidth="1.4" />
          <path d="M0 56 L56 0 L112 56" stroke="currentColor" fill="none" strokeWidth="1.4" />
          <path d="M56 42 L70 56 L56 70 L42 56 Z" stroke="currentColor" fill="none" strokeWidth="1.4" />
          <circle cx="56" cy="56" r="2.2" fill="currentColor" />
          <path d="M14 84 L20 90 L14 96 L8 90 Z" fill="currentColor" opacity="0.6" />
          <path d="M98 84 L104 90 L98 96 L92 90 Z" fill="currentColor" opacity="0.6" />
          <path d="M14 16 L20 22 L14 28 L8 22 Z" fill="currentColor" opacity="0.6" />
          <path d="M98 16 L104 22 L98 28 L92 22 Z" fill="currentColor" opacity="0.6" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#motif-africain)" />
    </svg>
  );
}
