import { Sparkles, Leaf, Landmark, Coins } from "lucide-react";
import { useReveal, useTitle } from "../hooks/useReveal";
import PageHero from "../components/PageHero";
import SectionHeading from "../components/SectionHeading";
import InfoCard from "../components/InfoCard";
import CtaBand from "../components/CtaBand";

const AXES = [
  {
    icon: <Sparkles className="h-7 w-7" />,
    title: "Le Développement Spirituel",
    description:
      "Révéler à chaque être sa dimension spirituelle : consultations du Fâ, médiumnité, cartomancie, voyance et rituels de haute spiritualité pour éclairer les choix, lever les blocages et ouvrir les chemins que l’on croyait fermés.",
  },
  {
    icon: <Leaf className="h-7 w-7" />,
    title: "Le Développement Sanitaire",
    description:
      "Promouvoir le bien-être par la pharmacopée béninoise et africaine, en complémentarité assumée avec la médecine moderne : un accompagnement naturel et traditionnel qui respecte, prolonge et ne remplace jamais le suivi médical.",
  },
  {
    icon: <Landmark className="h-7 w-7" />,
    title: "Le Développement Socio-Culturel",
    description:
      "Transmettre et valoriser les traditions endogènes du Bénin — la langue des ancêtres, les rites, les arts et les savoirs des couvents — pour que la culture vive, s’enseigne et rayonne au-delà des frontières.",
  },
  {
    icon: <Coins className="h-7 w-7" />,
    title: "Le Développement Économique",
    description:
      "Accompagner la prospérité : bénédiction des projets, ouverture des chemins professionnels et soutien des initiatives locales, des entrepreneurs et de la diaspora qui investissent au pays.",
  },
];

export default function MissionVision() {
  const scope = useReveal<HTMLDivElement>();
  useTitle("Mission & Vision — Dah Sonon-Biti");

  return (
    <div ref={scope}>
      <PageHero
        kicker="Mission & Vision"
        title={
          <>
            Une Mission Au-Delà <span className="text-rouge">du Visible</span>
          </>
        }
        subtitle="Ce que Dah SONON-BITI accomplit dans ses consultations n’est que la partie visible d’une mission plus vaste, qui engage l’humain tout entier."
      />

      {/* Citation de mission */}
      <section className="bg-gris py-24 md:py-32">
        <div className="container-site text-center">
          <span data-reveal className="kicker">
            <span className="h-px w-7 bg-rouge/50" aria-hidden="true" />
            La mission
            <span className="h-px w-7 bg-rouge/50" aria-hidden="true" />
          </span>
          <p
            data-reveal
            data-delay="0.1"
            className="mx-auto mt-8 max-w-4xl text-2xl font-semibold leading-[1.3] tracking-tight text-noir md:text-4xl"
          >
            <span className="text-rouge">«</span> Œuvrer pour le développement Spirituel, Sanitaire,
            Socio-Culturel et Économique de l’être humain.{" "}
            <span className="text-rouge">»</span>
          </p>
          <p
            data-reveal
            data-delay="0.18"
            className="mx-auto mt-8 max-w-2xl text-base leading-relaxed text-neutral-500"
          >
            Quatre axes, un seul cap. Chacun d’eux déploie cette mission en actions concrètes,
            sur le terrain comme dans l’invisible.
          </p>
        </div>
      </section>

      {/* Les 4 axes */}
      <section className="bg-blanc py-24 md:py-32">
        <div className="container-site">
          <SectionHeading
            kicker="Les quatre axes"
            title="Quatre Territoires, Une Même Destination : l’Épanouissement de l’Humain"
          />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:mt-16">
            {AXES.map((axe, i) => (
              <InfoCard
                key={axe.title}
                icon={axe.icon}
                title={axe.title}
                description={axe.description}
                delay={i * 0.08}
                tone="tinted"
              />
            ))}
          </div>
        </div>
      </section>

      {/* La vision */}
      <section className="relative overflow-hidden bg-noir py-24 md:py-32">
        <span
          className="pointer-events-none absolute -right-24 top-1/2 hidden -translate-y-1/2 select-none text-[26rem] font-bold leading-none text-blanc/[0.03] lg:block"
          aria-hidden="true"
        >
          4
        </span>
        <div className="container-site relative">
          <div className="max-w-3xl">
            <span data-reveal className="kicker">
              La vision
              <span className="h-px w-10 bg-rouge/60" aria-hidden="true" />
            </span>
            <h2
              data-reveal
              data-delay="0.08"
              className="mt-5 text-3xl font-bold leading-[1.12] tracking-tight text-blanc md:text-[2.6rem]"
            >
              Faire de la Tradition Endogène Béninoise une Force Reconnue dans le Monde Entier
            </h2>
            <div data-reveal data-delay="0.16" className="mt-7 space-y-5 text-[15px] leading-relaxed text-blanc/60 md:text-base">
              <p>
                Un pont entre la sagesse des ancêtres et les défis du monde moderne — voilà ce que
                Dah SONON-BITI construit, consultation après consultation, cérémonie après
                cérémonie.
              </p>
              <p>
                Sa vision est celle d’un héritage qui ne se fige pas dans le passé, mais qui éclaire
                l’avenir : une tradition endogène assumée, crédible et rayonnante, au service de
                l’humain d’ici et de la diaspora.
              </p>
            </div>
          </div>
          <div className="mt-14 grid gap-5 border-t border-blanc/10 pt-12 sm:grid-cols-3">
            {[
              { value: "Tradition", label: "Héritée des couvents sacrés du Bénin" },
              { value: "Complémentarité", label: "Médecine moderne & pharmacopée africaine" },
              { value: "Rayonnement", label: "Du Bénin vers toute la diaspora" },
            ].map((item, i) => (
              <div key={item.value} data-reveal data-delay={String(0.08 + i * 0.08)}>
                <p className="text-xl font-semibold tracking-tight text-rouge md:text-2xl">{item.value}</p>
                <p className="mt-2 text-sm leading-relaxed text-blanc/55">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaBand
        title="Cette Mission Peut Commencer Par Vous."
        text="Quel que soit le point de départ — spirituel, relationnel, professionnel — le premier pas est une simple conversation."
      />
    </div>
  );
}
