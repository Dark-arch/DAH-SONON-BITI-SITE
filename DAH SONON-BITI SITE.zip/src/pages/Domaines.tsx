import { useState } from "react";
import { Leaf, HeartPulse, Sparkles, ShieldCheck, Landmark, ZoomIn } from "lucide-react";
import { useReveal, useTitle } from "../hooks/useReveal";
import Lightbox from "../components/Lightbox";
import CtaBand from "../components/CtaBand";
import SectionHeading from "../components/SectionHeading";

const DOMAINES = [
  {
    icon: <Leaf className="h-6 w-6" />,
    title: "La Médecine Traditionnelle Béninoise et Africaine",
    paragraphs: [
      "Héritier des savoirs des plantes du Bénin et d’Afrique, Dah SONON-BITI pratique une pharmacopée ancestrale transmise par les anciens des couvents. Cet art traditionnel accompagne naturellement le bien-être : vitalité et énergie, confort digestif, équilibre du corps et de l’esprit, ainsi qu’un soutien traditionnel de la fertilité — toujours en complément d’un suivi médical.",
      "Chaque préparation est pensée avec la rigueur d’un praticien formé aux sciences de la santé et la sagesse d’un gardien de tradition : les bonnes plantes, les bons gestes, les bonnes paroles.",
    ],
  },
  {
    icon: <HeartPulse className="h-6 w-6" />,
    title: "La Médecine Moderne",
    paragraphs: [
      "Formé aux sciences de la santé et ancien infirmier de la Société Lion d’Or Bénin, Dah SONON-BITI parle le langage du monde médical. Cette double culture fait de lui un interlocuteur rare : capable de dialoguer avec les médecins, de comprendre les parcours de soins et d’orienter chacun vers le suivi adapté.",
      "Cette formation n’est pas un vernis : elle garantit que son accompagnement traditionnel s’inscrit toujours dans une démarche responsable, en complémentarité avec le corps médical — jamais à sa place.",
    ],
  },
  {
    icon: <Sparkles className="h-6 w-6" />,
    title: "La Parapsychologie et la Haute Spiritualité",
    paragraphs: [
      "Prêtre de Fâ Oroumila, médium, cartomancien et voyant, il interroge l’invisible pour éclairer le visible. Consultations du Fâ, lecture des signes, rituels de haute spiritualité, travaux de purification et levers de blocages : un art rigoureux, hérité des grands maîtres, exercé avec la gravité que méritent les forces invoquées.",
      "C’est ici que se jouent les grands retournements : les situations que rien ne semblait pouvoir débloquer trouvent, dans le langage du Fâ, une issue que l’on n’osait plus espérer.",
    ],
  },
  {
    icon: <ShieldCheck className="h-6 w-6" />,
    title: "La Protection et la Sauvegarde de l’Environnement",
    paragraphs: [
      "La tradition endogène enseigne que l’humain et la nature ne font qu’un. Rituel de protection du foyer, purification des lieux de vie et de travail, lutte contre les influences néfastes : Dah SONON-BITI œuvre à rétablir l’équilibre entre les personnes, leur environnement et les forces qui les habitent.",
      "Cette vigilance s’étend à la terre elle-même : à travers son ONG, il porte des actions concrètes de protection de l’environnement, fidèle à l’enseignement des ancêtres pour qui la nature est un temple.",
    ],
  },
  {
    icon: <Landmark className="h-6 w-6" />,
    title: "La Promotion Culturelle, Cultuelle et Sociale",
    paragraphs: [
      "Conférences, cérémonies publiques, transmission aux jeunes générations, accueil de la diaspora en quête de racines : Dah SONON-BITI fait vivre la culture endogène béninoise et lui donne la place qu’elle mérite dans le concert des nations.",
      "Par l’ONG Savoir Vivre Bénin, cette promotion devient solidarité : éducation, entraide, présence auprès des plus démunis. La tradition, chez lui, ne contemple pas le passé — elle sert le présent.",
    ],
  },
];

const GALLERY = [
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893048/Max_a_Enhance_this_image_1.png",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893039/Max_a_Enhance_this_image_3.png",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893039/Max_a_Enhance_this_image_5.png",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893040/IMG-20260914-WA0036.jpg",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893040/IMG-20260914-WA0028.jpg",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893040/Max_a_Enhance_this_image_2.png",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893041/IMG-20260914-WA0027.jpg",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893041/IMG-20260914-WA0025.jpg",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893045/Max_a_Enhance_this_image_a_1.png",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893046/Max_a_Enhance_this_image_4.png",
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_600/v1790893286/IMG-20260914-WA0018.jpg",
];

export default function Domaines() {
  const scope = useReveal<HTMLDivElement>();
  useTitle("Domaines d'Intervention — Dah Sonon-Biti");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  return (
    <div ref={scope}>
      <section className="bg-blanc pt-32 pb-16 md:pt-48 md:pb-24 border-b border-neutral-100">
        <div className="container-site">
          <span className="text-rouge text-[13px] font-bold uppercase tracking-widest">
            Domaines d'intervention
          </span>
          <h1 className="mt-8 text-4xl font-bold tracking-tight text-noir md:text-[3.5rem]">
            Cinq domaines. Une même exigence.
          </h1>
        </div>
      </section>

      {/* Les 5 domaines détaillés */}
      <section className="bg-blanc py-20 md:py-28">
        <div className="container-site">
          {DOMAINES.map((domaine, i) => (
            <div
              key={domaine.title}
              className={`grid gap-8 md:grid-cols-[150px_1fr] md:gap-16 ${
                i < DOMAINES.length - 1 ? "border-b border-neutral-200 pb-16 md:pb-20" : ""
              } ${i > 0 ? "pt-16 md:pt-20" : ""}`}
            >
              <div className="md:sticky md:top-28 md:self-start">
                <p
                  data-reveal
                  className="text-[13px] font-bold text-rouge uppercase tracking-widest mb-4"
                >
                  {String(i + 1).padStart(2, "0")} / {domaine.title.split(' ')[0]}
                </p>
                <div
                  data-reveal
                  data-delay="0.08"
                  className="mt-4 flex h-11 w-11 items-center justify-center rounded-xl bg-rouge/[0.06] text-rouge"
                >
                  {domaine.icon}
                </div>
              </div>
              <div>
                <h2 data-reveal className="max-w-3xl text-2xl font-semibold tracking-tight text-noir md:text-[2rem] md:leading-[1.2]">
                  {domaine.title}
                </h2>
                <div className="mt-6 max-w-3xl space-y-5">
                  {domaine.paragraphs.map((paragraph, j) => (
                    <p
                      key={j}
                      data-reveal
                      data-delay={String(0.1 + j * 0.06)}
                      className="text-[15px] leading-relaxed text-neutral-600 md:text-base"
                    >
                      {paragraph}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Galerie */}
      <section className="bg-gris py-24 md:py-32">
        <div className="container-site">
          <SectionHeading
            kicker="Galerie"
            title="Dans l’Exercice de Sa Mission"
            description="Instants de cérémonies, de consultations et d’engagement — un aperçu du quotidien de Celui que l’on surnomme Le Buffle."
          />
          <div className="mt-14 columns-1 gap-6 sm:columns-2 lg:mt-16 lg:columns-3 [column-fill:balance]">
            {GALLERY.map((src, i) => (
              <button
                key={src}
                data-reveal
                data-delay={String((i % 3) * 0.08)}
                onClick={() => setLightboxIndex(i)}
                className="group relative mb-6 block w-full overflow-hidden rounded-2xl break-inside-avoid focus:outline-none focus-visible:ring-4 focus-visible:ring-rouge/40"
                aria-label={`Agrandir la photo ${i + 1}`}
              >
                <img
                  src={src}
                  alt={`Dah Sonon-Biti dans l'exercice de sa mission — photo ${i + 1}`}
                  className="aspect-[9/16] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                  loading={i < 3 ? "eager" : "lazy"}
                />
                <span className="absolute inset-0 bg-noir/0 transition-colors duration-500 group-hover:bg-noir/30" />
                <span className="absolute right-4 top-4 flex h-10 w-10 translate-y-1 items-center justify-center rounded-full bg-blanc/95 text-noir opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                  <ZoomIn className="h-4.5 w-4.5" />
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <Lightbox
        images={GALLERY}
        index={lightboxIndex}
        onClose={() => setLightboxIndex(null)}
        onNavigate={setLightboxIndex}
      />

      <CtaBand
        title="Votre Situation Mérite un Regard d’Expert."
        text="Quel que soit le domaine qui vous préoccupe, une consultation permet d’y voir clair — et d’agir."
      />
    </div>
  );
}
