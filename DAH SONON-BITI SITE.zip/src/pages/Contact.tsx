import { useRef, useState, type FormEvent } from "react";
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Landmark,
  Video,
  CheckCircle2,
  Lock,
  Send,
  Loader2,
} from "lucide-react";
import { useReveal, useTitle } from "../hooks/useReveal";
import PageHero from "../components/PageHero";
import WhatsAppIcon, { WHATSAPP_URL } from "../components/WhatsAppIcon";

const OBJET_OPTIONS = [
  "Consultation du Fâ / Voyance",
  "Protection / Désenvoûtement",
  "Prospérité / Affaires",
  "Bien-être / Pharmacopée traditionnelle",
  "Amour / Couple / Famille",
  "Autre",
];

interface FormState {
  nom: string;
  pays: string;
  ville: string;
  whatsapp: string;
  email: string;
  objets: string[];
  description: string;
  mode: "" | "presentiel" | "distance";
  siteWeb: string; // honeypot
}

const INITIAL_FORM: FormState = {
  nom: "",
  pays: "",
  ville: "",
  whatsapp: "",
  email: "",
  objets: [],
  description: "",
  mode: "",
  siteWeb: "",
};

export default function Contact() {
  const scope = useReveal<HTMLDivElement>();
  useTitle("Contact & Rendez-vous — Dah Sonon-Biti");

  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const mountedAt = useRef(Date.now());

  const setField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const toggleObjet = (objet: string) => {
    setForm((prev) => ({
      ...prev,
      objets: prev.objets.includes(objet)
        ? prev.objets.filter((o) => o !== objet)
        : [...prev.objets, objet],
    }));
  };

  // Validation côté client (le traitement réel doit toujours passer par
  // une fonction serverless — jamais de confiance aux seules données du navigateur).
  const validate = (): Partial<Record<keyof FormState, string>> => {
    const errs: Partial<Record<keyof FormState, string>> = {};
    if (form.nom.trim().length < 3) errs.nom = "Veuillez indiquer votre nom complet.";
    if (form.pays.trim().length < 2) errs.pays = "Veuillez indiquer votre pays de résidence.";
    if (form.ville.trim().length < 2) errs.ville = "Veuillez indiquer votre ville.";
    if (!/^\+?[0-9\s().-]{8,20}$/.test(form.whatsapp.trim()))
      errs.whatsapp = "Veuillez indiquer un numéro WhatsApp valide (indicatif inclus).";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim()))
      errs.email = "Veuillez indiquer une adresse email valide.";
    if (form.objets.length === 0) errs.objets = "Veuillez sélectionner au moins un objet.";
    if (form.description.trim().length < 20)
      errs.description = "Décrivez votre situation en quelques phrases (20 caractères minimum).";
    if (!form.mode) errs.mode = "Veuillez choisir un mode de consultation.";
    return errs;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    // Anti-spam : honeypot rempli ou formulaire soumis trop vite = sollicitation robot.
    if (form.siteWeb !== "" || Date.now() - mountedAt.current < 2500) {
      setSent(true); // réponse neutre, sans signaler la détection
      return;
    }

    setSending(true);
    // Point d'insertion de l'appel vers la fonction serverless sécurisée
    // (validation + reCAPTCHA/hCaptcha côté serveur, aucun secret dans le bundle).
    window.setTimeout(() => {
      setSending(false);
      setSent(true);
    }, 1200);
  };

  const waPrefill = `${WHATSAPP_URL}?text=${encodeURIComponent(
    "Bonjour Sa Majesté, je souhaite prendre rendez-vous pour une consultation."
  )}`;

  return (
    <div ref={scope}>
      <PageHero
        kicker="Contact & Rendez-vous"
        title={
          <>
            Prenez Rendez-Vous avec <span className="text-rouge">Le Buffle</span>
          </>
        }
        subtitle="Chaque grande transformation commence par une première conversation. Décrivez votre situation : vous serez recontacté avec un créneau de consultation, en présentiel à Abomey-Calavi ou à distance, où que vous soyez."
      />

      <section className="bg-gris py-20 md:py-28">
        <div className="container-site grid gap-10 lg:grid-cols-5 lg:gap-14">
          {/* ——— Colonne coordonnées & modalités ——— */}
          <div className="space-y-6 lg:col-span-2">
            <div data-reveal className="rounded-2xl border-l-4 border-rouge bg-blanc p-7 shadow-[0_1px_12px_rgba(10,10,10,0.05)] md:p-8">
              <h2 className="text-lg font-semibold tracking-tight text-noir">Coordonnées</h2>
              <ul className="mt-6 space-y-5 text-sm leading-relaxed text-neutral-600">
                <li className="flex items-start gap-3.5">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rouge/[0.06] text-rouge">
                    <MapPin className="h-5 w-5" />
                  </span>
                  <span className="pt-1.5">
                    Abomey-Calavi, République du Bénin
                    <br />
                    BP 2757
                  </span>
                </li>
                <li className="flex items-start gap-3.5">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rouge/[0.06] text-rouge">
                    <Phone className="h-5 w-5" />
                  </span>
                  <span className="pt-1.5">
                    <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="font-medium text-noir transition-colors hover:text-rouge">
                      +229 66 41 11 16
                    </a>{" "}
                    <span className="text-neutral-400">(WhatsApp)</span>
                    <br />
                    +229 95 05 64 72 <span className="text-neutral-400">(appels)</span>
                  </span>
                </li>
                <li className="flex items-start gap-3.5">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rouge/[0.06] text-rouge">
                    <Mail className="h-5 w-5" />
                  </span>
                  <a href="mailto:dahsononbiti@gmail.com" className="pt-2.5 font-medium text-noir transition-colors hover:text-rouge">
                    dahsononbiti@gmail.com
                  </a>
                </li>
                <li className="flex items-start gap-3.5">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rouge/[0.06] text-rouge">
                    <Clock className="h-5 w-5" />
                  </span>
                  <span className="pt-1.5">
                    Lundi – Samedi
                    <br />
                    8h00 – 20h00 (GMT+1)
                  </span>
                </li>
              </ul>
              <a
                href={waPrefill}
                target="_blank"
                rel="noreferrer"
                className="btn-primary mt-7 w-full"
              >
                <WhatsAppIcon className="h-4.5 w-4.5" />
                Écrire directement sur WhatsApp
              </a>
            </div>

            <div data-reveal data-delay="0.1" className="rounded-2xl bg-blanc p-7 shadow-[0_1px_12px_rgba(10,10,10,0.05)] md:p-8">
              <h2 className="text-lg font-semibold tracking-tight text-noir">
                Modalités de consultation
              </h2>
              <div className="mt-6 space-y-4">
                <div className="flex items-start gap-4 rounded-xl bg-gris p-5">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-noir/[0.05] text-rouge">
                    <Landmark className="h-5.5 w-5.5" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-noir">En présentiel</p>
                    <p className="mt-1 text-[13px] leading-relaxed text-neutral-600">
                      Au Palais / Temple d’Abomey-Calavi, sur rendez-vous uniquement.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4 rounded-xl bg-gris p-5">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-noir/[0.05] text-rouge">
                    <Video className="h-5.5 w-5.5" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-noir">À distance</p>
                    <p className="mt-1 text-[13px] leading-relaxed text-neutral-600">
                      Par WhatsApp ou visioconférence — Bénin, Afrique, Europe, Amériques et toute
                      la diaspora.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ——— Formulaire de prise de rendez-vous ——— */}
          <div data-reveal data-delay="0.15" className="lg:col-span-3">
            <div className="rounded-2xl bg-blanc p-7 shadow-[0_1px_12px_rgba(10,10,10,0.05)] md:p-10">
              {sent ? (
                <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
                  <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-rouge/[0.07] text-rouge">
                    <CheckCircle2 className="h-8 w-8" />
                  </span>
                  <h2 className="mt-6 text-2xl font-semibold tracking-tight text-noir">
                    Demande transmise
                  </h2>
                  <p className="mt-3 max-w-md text-[15px] leading-relaxed text-neutral-600">
                    Votre demande a bien été transmise. Sa Majesté Dah Sonon-Biti ou son équipe vous
                    recontactera dans les meilleurs délais.
                  </p>
                  <button
                    onClick={() => {
                      setForm(INITIAL_FORM);
                      setSent(false);
                      mountedAt.current = Date.now();
                    }}
                    className="btn-dark mt-8"
                  >
                    Envoyer une autre demande
                  </button>
                </div>
              ) : (
                <>
                  <h2 className="text-xl font-semibold tracking-tight text-noir md:text-2xl">
                    Demande de consultation
                  </h2>
                  <p className="mt-2 text-sm text-neutral-500">
                    Tous les champs marqués d’un astérisque sont requis.
                  </p>

                  <form onSubmit={handleSubmit} noValidate className="mt-8 space-y-6">
                    <div>
                      <label htmlFor="nom" className="input-label">
                        Nom complet *
                      </label>
                      <input
                        id="nom"
                        type="text"
                        className="input-field"
                        placeholder="Votre nom et vos prénoms"
                        value={form.nom}
                        onChange={(e) => setField("nom", e.target.value)}
                        autoComplete="name"
                      />
                      {errors.nom && <p className="mt-2 text-xs font-medium text-rouge">{errors.nom}</p>}
                    </div>

                    <div className="grid gap-6 sm:grid-cols-2">
                      <div>
                        <label htmlFor="pays" className="input-label">
                          Pays de résidence *
                        </label>
                        <input
                          id="pays"
                          type="text"
                          className="input-field"
                          placeholder="Ex. France"
                          value={form.pays}
                          onChange={(e) => setField("pays", e.target.value)}
                          autoComplete="country-name"
                        />
                        {errors.pays && <p className="mt-2 text-xs font-medium text-rouge">{errors.pays}</p>}
                      </div>
                      <div>
                        <label htmlFor="ville" className="input-label">
                          Ville *
                        </label>
                        <input
                          id="ville"
                          type="text"
                          className="input-field"
                          placeholder="Ex. Paris"
                          value={form.ville}
                          onChange={(e) => setField("ville", e.target.value)}
                          autoComplete="address-level2"
                        />
                        {errors.ville && <p className="mt-2 text-xs font-medium text-rouge">{errors.ville}</p>}
                      </div>
                    </div>

                    <div className="grid gap-6 sm:grid-cols-2">
                      <div>
                        <label htmlFor="whatsapp" className="input-label">
                          Numéro WhatsApp *
                        </label>
                        <input
                          id="whatsapp"
                          type="tel"
                          className="input-field"
                          placeholder="Ex. +33 6 12 34 56 78"
                          value={form.whatsapp}
                          onChange={(e) => setField("whatsapp", e.target.value)}
                          autoComplete="tel"
                        />
                        {errors.whatsapp && (
                          <p className="mt-2 text-xs font-medium text-rouge">{errors.whatsapp}</p>
                        )}
                      </div>
                      <div>
                        <label htmlFor="email" className="input-label">
                          Email *
                        </label>
                        <input
                          id="email"
                          type="email"
                          className="input-field"
                          placeholder="vous@exemple.com"
                          value={form.email}
                          onChange={(e) => setField("email", e.target.value)}
                          autoComplete="email"
                        />
                        {errors.email && <p className="mt-2 text-xs font-medium text-rouge">{errors.email}</p>}
                      </div>
                    </div>

                    <fieldset>
                      <legend className="input-label">Objet de la demande *</legend>
                      <div className="grid gap-3 sm:grid-cols-2">
                        {OBJET_OPTIONS.map((objet) => (
                          <label
                            key={objet}
                            className={`flex cursor-pointer items-center gap-3 rounded-xl border px-4 py-3.5 text-[13.5px] font-medium transition-all duration-300 ${
                              form.objets.includes(objet)
                                ? "border-rouge bg-rouge/[0.05] text-noir"
                                : "border-neutral-200 text-neutral-600 hover:border-neutral-300"
                            }`}
                          >
                            <input
                              type="checkbox"
                              className="h-4 w-4 shrink-0 accent-[#B01F24]"
                              checked={form.objets.includes(objet)}
                              onChange={() => toggleObjet(objet)}
                            />
                            {objet}
                          </label>
                        ))}
                      </div>
                      {errors.objets && <p className="mt-2 text-xs font-medium text-rouge">{errors.objets}</p>}
                    </fieldset>

                    <div>
                      <label htmlFor="description" className="input-label">
                        Description de votre situation *
                      </label>
                      <textarea
                        id="description"
                        rows={5}
                        className="input-field resize-y"
                        placeholder="Décrivez en quelques phrases ce qui vous amène : contexte, blocages, attentes…"
                        value={form.description}
                        onChange={(e) => setField("description", e.target.value)}
                      />
                      {errors.description && (
                        <p className="mt-2 text-xs font-medium text-rouge">{errors.description}</p>
                      )}
                    </div>

                    <fieldset>
                      <legend className="input-label">Mode de consultation souhaité *</legend>
                      <div className="grid gap-3 sm:grid-cols-2">
                        {[
                          { value: "presentiel", label: "En présentiel — Abomey-Calavi" },
                          { value: "distance", label: "À distance — WhatsApp / visio" },
                        ].map((option) => (
                          <label
                            key={option.value}
                            className={`flex cursor-pointer items-center gap-3 rounded-xl border px-4 py-3.5 text-[13.5px] font-medium transition-all duration-300 ${
                              form.mode === option.value
                                ? "border-rouge bg-rouge/[0.05] text-noir"
                                : "border-neutral-200 text-neutral-600 hover:border-neutral-300"
                            }`}
                          >
                            <input
                              type="radio"
                              name="mode"
                              className="h-4 w-4 shrink-0 accent-[#B01F24]"
                              checked={form.mode === option.value}
                              onChange={() => setField("mode", option.value as FormState["mode"])}
                            />
                            {option.label}
                          </label>
                        ))}
                      </div>
                      {errors.mode && <p className="mt-2 text-xs font-medium text-rouge">{errors.mode}</p>}
                    </fieldset>

                    {/* Honeypot anti-spam — invisible pour les humains */}
                    <div className="absolute -left-[9999px] top-auto h-px w-px overflow-hidden" aria-hidden="true">
                      <label htmlFor="siteWeb">Ne pas remplir</label>
                      <input
                        id="siteWeb"
                        type="text"
                        tabIndex={-1}
                        autoComplete="off"
                        value={form.siteWeb}
                        onChange={(e) => setField("siteWeb", e.target.value)}
                      />
                    </div>

                    <button type="submit" className="btn-primary w-full" disabled={sending}>
                      {sending ? (
                        <>
                          <Loader2 className="h-4.5 w-4.5 animate-spin" />
                          Transmission en cours…
                        </>
                      ) : (
                        <>
                          <Send className="h-4.5 w-4.5" />
                          Envoyer ma Demande de Consultation
                        </>
                      )}
                    </button>

                    <p className="flex items-start gap-2.5 text-xs leading-relaxed text-neutral-400">
                      <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rouge/60" />
                      Vos informations restent strictement confidentielles et ne sont utilisées que
                      pour traiter votre demande. Connexion sécurisée HTTPS — aucun secret exposé.
                    </p>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
