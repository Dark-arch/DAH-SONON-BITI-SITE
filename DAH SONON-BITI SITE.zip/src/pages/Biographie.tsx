import { Check, Landmark, ShieldCheck, Anchor, Flame } from "lucide-react";
import { useReveal, useTitle } from "../hooks/useReveal";
import PageHero from "../components/PageHero";
import CtaBand from "../components/CtaBand";

const BUFFALO_MEANINGS = [
  {
    icon: <Flame className="h-6 w-6" />,
    title: "La Force Inarrêtable",
    text: "Un buffle lancé ne s’arrête jamais à mi-chemin. Ce nom annonce une énergie qui va au bout de chaque mission entreprise, jusqu’à la résolution complète du problème confié.",
  },
  {
    icon: <ShieldCheck className="h-6 w-6" />,
    title: "L’Invulnérabilité",
    text: "Peu de prédateurs osent s’en prendre à un buffle adulte. Ce nom proclame une protection spirituelle qui place ceux qu’il garde hors d’atteinte du mal.",
  },
  {
    icon: <Anchor className="h-6 w-6" />,
    title: "La Stabilité",
    text: "Ancré au sol, massif, inébranlable : le buffle incarne un socle sur lequel on peut compter — une présence qui ne vacille pas quand tout tremble alentour.",
  },
  {
    icon: <Landmark className="h-6 w-6" />,
    title: "La Persévérance",
    text: "Savane brûlée ou forêt dense, le buffle avance. Ce nom est la promesse d’un accompagnement qui ne lâche jamais, quelle que soit la durée du combat.",
  },
];

const ONG_DOMAINS = [
  "L’éducation et l’instruction des plus jeunes",
  "La santé communautaire et l’accès aux soins de premier recours",
  "La solidarité envers les personnes vulnérables et démunies",
  "La protection de l’environnement et des écosystèmes",
  "La promotion culturelle et la transmission des traditions endogènes",
];

export default function Biographie() {
  const scope = useReveal<HTMLDivElement>();
  useTitle("Biographie — Dah Sonon-Biti « Le Buffle »");

  return (
    <div ref={scope}>
      <PageHero
        kicker="Biographie"
        title={
          <>
            Sa Majesté Dah SONON-BITI <span className="text-rouge">« Le Buffle »</span> (Buffalo)
          </>
        }
        epigraph="Le Très Puissant. L’Incontournable. L’Invincible. L’Indomptable."
        subtitle="Cinq chapitres pour comprendre l’homme derrière le nom : ses racines, sa formation, sa mission et l’héritage qu’il porte."
      />

      <section className="bg-blanc py-20 md:py-28">
        <div className="container-site">
          {/* Chapitre 01 — Les Racines */}
          <div className="grid gap-10 border-b border-neutral-200 pb-20 md:grid-cols-[210px_1fr] md:gap-16 md:pb-24">
            <div className="md:sticky md:top-28 md:self-start">
              <p
                data-reveal
                className="text-7xl font-bold leading-none text-transparent md:text-8xl"
                style={{ WebkitTextStroke: "1.5px #B01F24" }}
              >
                01
              </p>
              <p data-reveal data-delay="0.08" className="mt-3 text-[11px] font-semibold uppercase tracking-[0.3em] text-rouge">
                Chapitre premier
              </p>
            </div>
            <div>
              <h2 data-reveal className="text-3xl font-semibold tracking-tight text-noir md:text-4xl">
                Les Racines
              </h2>
              <div data-reveal data-delay="0.1" className="mt-6 space-y-5 max-w-3xl text-[15px] leading-relaxed text-neutral-600 md:text-base">
                <p>
                  Certains naissent sous une étoile ; Dah SONON-BITI est né sous le signe du sacré.
                  Fils de Dah MÊTONOU et de Madame Ayiountchi HOUANDOSSI, il grandit dans un
                  environnement où la tradition n’est pas un folklore, mais une respiration
                  quotidienne.
                </p>
                <p>
                  Dès l’enfance, il est immergé dans les couvents sacrés du Bénin — ces lieux où se
                  transmettent, de génération en génération, les enseignements des ancêtres et les
                  secrets de l’invisible. Très tôt, les anciens reconnaissent en lui les signes
                  d’une vocation rare : celle d’un intermédiaire entre le monde visible et le monde
                  invisible, appelé à guider, protéger et guérir.
                </p>
              </div>
            </div>
          </div>

          {/* Chapitre 02 — La Formation */}
          <div className="grid gap-10 border-b border-neutral-200 py-20 md:grid-cols-[210px_1fr] md:gap-16 md:py-24">
            <div className="md:sticky md:top-28 md:self-start">
              <p
                data-reveal
                className="text-7xl font-bold leading-none text-transparent md:text-8xl"
                style={{ WebkitTextStroke: "1.5px #B01F24" }}
              >
                02
              </p>
              <p data-reveal data-delay="0.08" className="mt-3 text-[11px] font-semibold uppercase tracking-[0.3em] text-rouge">
                Chapitre deux
              </p>
            </div>
            <div>
              <h2 data-reveal className="text-3xl font-semibold tracking-tight text-noir md:text-4xl">
                La Formation
              </h2>
              <div data-reveal data-delay="0.1" className="mt-6 space-y-5 max-w-3xl text-[15px] leading-relaxed text-neutral-600 md:text-base">
                <p>
                  Parallèlement à son cheminement initiatique, Dah SONON-BITI suit une formation
                  dans les sciences de la santé et exerce comme infirmier au sein de la Société Lion
                  d’Or Bénin. De cette expérience naît une conviction qui guidera toute son œuvre :
                  la tradition et la médecine moderne ne s’opposent pas — elles se complètent.
                  Aujourd’hui encore, il positionne son art comme un accompagnement traditionnel qui
                  dialogue avec le suivi médical, jamais comme son substitut.
                </p>
                <p>
                  Sur le plan spirituel, son parcours le conduit à la reconnaissance la plus haute :
                  il est sacré Prêtre de Fâ Oroumila. Maître de la géomancie du Fâ, il pratique
                  également la cartomancie, la médiumnité et la voyance — des disciplines
                  millénaires qu’il met au service d’une guidance précise, sérieuse et responsable.
                </p>
              </div>
            </div>
          </div>

          {/* Chapitre 03 — Le Nom Fort */}
          <div className="grid gap-10 border-b border-neutral-200 py-20 md:grid-cols-[210px_1fr] md:gap-16 md:py-24">
            <div className="md:sticky md:top-28 md:self-start">
              <p
                data-reveal
                className="text-7xl font-bold leading-none text-transparent md:text-8xl"
                style={{ WebkitTextStroke: "1.5px #B01F24" }}
              >
                03
              </p>
              <p data-reveal data-delay="0.08" className="mt-3 text-[11px] font-semibold uppercase tracking-[0.3em] text-rouge">
                Chapitre trois
              </p>
            </div>
            <div>
              <h2 data-reveal className="text-3xl font-semibold tracking-tight text-noir md:text-4xl">
                Le Nom Fort — Pourquoi « Le Buffle »
              </h2>
              <p data-reveal data-delay="0.1" className="mt-6 max-w-3xl text-[15px] leading-relaxed text-neutral-600 md:text-base">
                Dans la tradition endogène, un nom n’est jamais une étiquette : c’est une
                prophétie, un programme, une armure. Celui de « Buffle » lui a été attribué parce
                que sa trajectoire incarne, point par point, ce que l’animal représente dans
                l’imaginaire sacré de l’Afrique de l’Ouest.
              </p>
              <div className="mt-9 grid gap-5 sm:grid-cols-2">
                {BUFFALO_MEANINGS.map((meaning, i) => (
                  <div
                    key={meaning.title}
                    data-reveal
                    data-delay={String(0.08 + i * 0.07)}
                    className="group rounded-2xl bg-gris p-7 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_20px_45px_-16px_rgba(10,10,10,0.12)]"
                  >
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-rouge/[0.06] text-rouge transition-colors duration-500 group-hover:bg-rouge group-hover:text-blanc">
                      {meaning.icon}
                    </div>
                    <h3 className="mt-4 text-base font-semibold tracking-tight text-noir">
                      {meaning.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-neutral-600">{meaning.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Chapitre 04 — L'Engagement Social */}
          <div className="grid gap-10 border-b border-neutral-200 py-20 md:grid-cols-[210px_1fr] md:gap-16 md:py-24">
            <div className="md:sticky md:top-28 md:self-start">
              <p
                data-reveal
                className="text-7xl font-bold leading-none text-transparent md:text-8xl"
                style={{ WebkitTextStroke: "1.5px #B01F24" }}
              >
                04
              </p>
              <p data-reveal data-delay="0.08" className="mt-3 text-[11px] font-semibold uppercase tracking-[0.3em] text-rouge">
                Chapitre quatre
              </p>
            </div>
            <div>
              <h2 data-reveal className="text-3xl font-semibold tracking-tight text-noir md:text-4xl">
                L’Engagement Social
              </h2>
              <p data-reveal data-delay="0.1" className="mt-6 max-w-3xl text-[15px] leading-relaxed text-neutral-600 md:text-base">
                La grandeur ne se mesure pas seulement aux mystères que l’on maîtrise, mais au bien
                que l’on répand. Président-fondateur de l’ONG Savoir Vivre Bénin, Dah SONON-BITI
                porte sur le terrain une action concrète autour de cinq domaines :
              </p>
              <ul className="mt-8 grid max-w-3xl gap-4 sm:grid-cols-2">
                {ONG_DOMAINS.map((domain, i) => (
                  <li
                    key={domain}
                    data-reveal
                    data-delay={String(0.06 + i * 0.06)}
                    className={`flex items-start gap-3.5 rounded-xl bg-gris p-5 ${i === 4 ? "sm:col-span-2" : ""}`}
                  >
                    <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-rouge/[0.08] text-rouge">
                      <Check className="h-3.5 w-3.5" />
                    </span>
                    <span className="text-sm leading-relaxed text-neutral-700">{domain}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Chapitre 05 — L'Ancrage dans la Tradition */}
          <div className="grid gap-10 pt-20 md:grid-cols-[210px_1fr] md:gap-16 md:pt-24">
            <div className="md:sticky md:top-28 md:self-start">
              <p
                data-reveal
                className="text-7xl font-bold leading-none text-transparent md:text-8xl"
                style={{ WebkitTextStroke: "1.5px #B01F24" }}
              >
                05
              </p>
              <p data-reveal data-delay="0.08" className="mt-3 text-[11px] font-semibold uppercase tracking-[0.3em] text-rouge">
                Chapitre cinq
              </p>
            </div>
            <div>
              <h2 data-reveal className="text-3xl font-semibold tracking-tight text-noir md:text-4xl">
                L’Ancrage dans la Tradition
              </h2>
              <div data-reveal data-delay="0.1" className="mt-6 space-y-5 max-w-3xl text-[15px] leading-relaxed text-neutral-600 md:text-base">
                <p>
                  Gardien des pratiques ancestrales, Dah SONON-BITI veille sur un héritage que le
                  monde moderne menace trop souvent d’oublier : les rites de passage, les
                  cérémonies de protection, la langue des signes et celle des plantes.
                </p>
                <p>
                  Maître de la pharmacopée béninoise, il perpétue le savoir des feuilles, des
                  écorces et des racines, transmis par les anciens des couvents. Dans ses
                  consultations comme dans ses cérémonies, il tient le même cap, avec la constance
                  de l’animal dont il porte le nom : faire de la tradition une force vivante, au
                  service de ceux qui viennent à lui.
                </p>
              </div>
              <blockquote
                data-reveal
                data-delay="0.16"
                className="mt-9 max-w-3xl rounded-r-2xl border-l-4 border-rouge bg-gris p-7 text-[17px] font-semibold italic leading-relaxed text-noir md:p-8 md:text-xl"
              >
                « La force de la tradition pour éclairer le monde moderne. »
              </blockquote>
            </div>
          </div>
        </div>
      </section>

      <CtaBand
        title="Prêt à Écrire le Prochain Chapitre de Votre Vie ?"
        text="L’histoire du Buffle continue à travers celles et ceux qu’il accompagne. La vôtre peut commencer aujourd’hui."
      />
    </div>
  );
}
