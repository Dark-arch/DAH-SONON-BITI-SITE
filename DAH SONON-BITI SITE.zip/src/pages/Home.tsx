import { Link } from "react-router-dom";
import {
  Sparkles,
  ShieldCheck,
  Coins,
  Leaf,
  Landmark,
  HeartPulse,
  Globe,
  HandHeart,
  Lock,
  ArrowRight,
  ArrowDown,
  Quote,
} from "lucide-react";
import { useReveal, useTitle } from "../hooks/useReveal";
import InfoCard from "../components/InfoCard";
import SectionHeading from "../components/SectionHeading";
import BuffaloMark from "../components/BuffaloMark";
import WhatsAppIcon, { WHATSAPP_URL } from "../components/WhatsAppIcon";

const HERO_IMG =
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,e_blackwhite,co_rgb:6B1A1A,e_colorize:40,w_1920/v1790890896/Max_a_Enhance_this_image.png";
const PORTRAIT_IMG =
  "https://res.cloudinary.com/rqaqbeay/image/upload/f_auto,q_auto,w_900/v1790891632/Max_a_Enhance_this_image_a.png";

const BADGES = [
  "Tradition authentique du Bénin",
  "Double expertise : médecine moderne & traditionnelle",
  "Consultations en présentiel et à distance (diaspora)",
  "Président-Fondateur de l’ONG Savoir Vivre Bénin",
];

const SERVICES = [
  {
    icon: <Sparkles className="h-7 w-7" />,
    title: "Consultation du Fâ & Guidance Spirituelle",
    description:
      "Héritée de la géomancie ouest-africaine, la consultation du Fâ révèle l’origine profonde de vos difficultés et trace la voie à suivre. En présentiel ou à distance, où que vous soyez.",
    linkText: "Réserver une Consultation du Fâ",
  },
  {
    icon: <ShieldCheck className="h-7 w-7" />,
    title: "Protection, Désenvoûtement & Purification",
    description:
      "Neutralisation des énergies négatives, rituels de protection et purification de votre aura comme de votre lieu de vie — pour avancer enfin à l’abri de toute influence.",
    linkText: "Demander une Protection Immédiate",
  },
  {
    icon: <Coins className="h-7 w-7" />,
    title: "Prospérité des Affaires & Bénédiction de Projets",
    description:
      "Rituels d’ouverture de chemins, bénédiction de projets et accompagnement des entrepreneurs, des commerçants et de la diaspora vers une prospérité durable.",
    linkText: "Booster ma Prospérité",
  },
  {
    icon: <Leaf className="h-7 w-7" />,
    title: "Harmonisation de Foyer & Accompagnement Traditionnel",
    description:
      "Rituels d’harmonisation du couple et du foyer, accompagnement traditionnel du bien-être et de la fertilité en complément d’un suivi médical, pharmacopée béninoise au service de votre vitalité.",
    linkText: "Rétablir la Paix et l’Harmonie",
  },
];

const STRENGTHS = [
  {
    icon: <Landmark className="h-7 w-7" />,
    title: "Lignée Royale & Sacrée",
    description:
      "Fils de Dah MÊTONOU et d’Ayiountchi HOUANDOSSI, il porte l’héritage d’une lignée placée sous le signe du sacré, initiée dès l’enfance aux enseignements des couvents traditionnels du Bénin.",
  },
  {
    icon: <HeartPulse className="h-7 w-7" />,
    title: "Double Compétence Unique",
    description:
      "Ancien infirmier au sein de la Société Lion d’Or Bénin, il dialogue avec la médecine moderne et positionne la pharmacopée africaine comme un accompagnement naturel du bien-être, en complément du suivi médical.",
  },
  {
    icon: <BuffaloMark className="h-8 w-8" withRing={false} accent="currentColor" />,
    title: "La Force du Buffle",
    description:
      "Le buffle traverse savane et forêt dense sans jamais dévier de sa trajectoire. Cette énergie d’inarrêtable persévérance guide chacune de ses interventions spirituelles.",
  },
  {
    icon: <Globe className="h-7 w-7" />,
    title: "Présence Internationale",
    description:
      "De Cotonou à Paris, il accompagne en présentiel et à distance une clientèle venue d’Afrique, d’Europe et de toute la diaspora — la distance n’a jamais été un obstacle.",
  },
  {
    icon: <HandHeart className="h-7 w-7" />,
    title: "Engagement Social Prouvé",
    description:
      "Président-fondateur de l’ONG Savoir Vivre Bénin, il agit concrètement pour l’éducation, la santé communautaire, la solidarité et la protection de l’environnement.",
  },
  {
    icon: <Lock className="h-7 w-7" />,
    title: "Discrétion Absolue",
    description:
      "Chaque consultation est couverte par une confidentialité totale. Votre histoire, vos épreuves et vos secrets demeurent entre lui et vous — pour toujours.",
  },
];



const MARQUEE_ITEMS = [
  "Le Très Puissant",
  "L’Incontournable",
  "L’Invincible",
  "L’Indomptable",
  "Sa Majesté Dah SONON-BITI",
];

const KEY_FACTS = [
  {
    icon: <Sparkles className="h-5 w-5" />,
    title: "Prêtre de Fâ Oroumila",
    sub: "Reconnu par les couvents sacrés du Bénin",
  },
  {
    icon: <HeartPulse className="h-5 w-5" />,
    title: "Ancien infirmier",
    sub: "Société Lion d'Or Bénin — double compétence santé",
  },
  {
    icon: <HandHeart className="h-5 w-5" />,
    title: "Président-fondateur",
    sub: "ONG Savoir Vivre Bénin",
  },
];

export default function Home() {
  const scope = useReveal<HTMLDivElement>();
  useTitle("Dah Sonon-Biti « Le Buffle » — Prêtre de Fâ & Guérisseur Traditionnel du Bénin");

  return (
    <div ref={scope}>
      {/* ————— 3.1 HERO ————— */}
      <section className="relative flex min-h-[90svh] items-center overflow-hidden bg-noir">
        <img
          src={HERO_IMG}
          alt=""
          fetchPriority="high"
          className="absolute inset-0 h-full w-full object-cover"
          style={{ animation: "heroZoom 20s ease-out forwards", filter: "sepia(0.6) saturate(1.8) hue-rotate(-15deg) brightness(0.45)" }}
        />
        {/* Overlay rouge-brun pour renforcer le camaïeu */}
        <div className="absolute inset-0 bg-[#3a0a0a]/50 mix-blend-multiply" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a0505]/80 via-[#1a0505]/30 to-transparent" />
        
        <div className="container-site relative pb-16 pt-40 md:pb-20">
          <span data-hero="0" className="text-rouge text-[13px] font-bold uppercase tracking-widest">
            Dignitaire de la tradition endogène du Bénin
          </span>

          <h1
            data-hero="0.2"
            className="mt-6 max-w-5xl text-[2.8rem] font-bold leading-[1.05] tracking-tight text-blanc sm:text-6xl lg:text-[4.5rem]"
          >
            Sa Majesté Dah <br className="hidden md:block" />
            SONON-BITI <span className="text-rouge">« Le Buffle »</span> <br />
            <span className="font-medium">dit <span className="text-rouge">« AGBOGBÉTON »</span></span>
          </h1>

          <p data-hero="0.35" className="mt-6 text-base font-bold text-blanc/90 md:text-xl uppercase tracking-widest">
            Le Très Puissant. L’Incontournable. L’Invincible. L’Indomptable.
          </p>

          <p
            data-hero="0.5"
            className="mt-8 max-w-2xl text-base leading-relaxed text-blanc/70 md:text-lg"
          >
            Prêtre de Fâ Oroumila, Grand Maître Spirituel, Médium, Cartomancien, Voyant et
            Guérisseur Traditionnel. La sagesse millénaire des ancêtres du Bénin,
            portée par un parcours en soins infirmiers et en pharmacopée africaine, pour
            éclairer votre chemin.
          </p>

          <div data-hero="0.75" className="mt-10 flex flex-wrap items-center gap-4">
            <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="btn-primary">
              Consulter maintenant via WhatsApp
              <WhatsAppIcon className="h-4.5 w-4.5" />
            </a>
            <Link to="/biographie" className="btn-outline-light">
              Découvrir l’Histoire du Buffle
            </Link>
          </div>

          <div className="mt-16 grid grid-cols-1 gap-x-12 gap-y-6 border-t border-blanc/10 pt-10 sm:grid-cols-2 lg:grid-cols-4">
            {BADGES.map((badge, i) => (
              <div key={badge} data-hero={String(0.9 + i * 0.1)} className="flex items-center gap-3">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-rouge/20 text-rouge">
                  <Sparkles className="h-3 w-3" />
                </span>
                <span className="text-[12px] font-bold uppercase tracking-wider text-blanc/80 leading-tight">{badge}</span>
              </div>
            ))}
          </div>
        </div>

        <div
          data-hero="1.4"
          className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-blanc/50 md:flex"
        >
          <div className="flex h-9 w-5.5 justify-center rounded-full border border-blanc/25 pt-1.5">
            <span
              className="h-1.5 w-1 rounded-full bg-rouge"
              style={{ animation: "scrollDot 1.8s ease-in-out infinite" }}
            />
          </div>
          <ArrowDown className="h-3.5 w-3.5" />
        </div>
      </section>

      {/* Bandeau défilant — épithetes */}
      <div className="select-none overflow-hidden bg-rouge py-4 text-blanc" aria-hidden="true">
        <div className="animate-marquee flex w-max">
          {[0, 1].map((half) => (
            <div key={half} className="flex shrink-0 items-center">
              {MARQUEE_ITEMS.concat(MARQUEE_ITEMS).map((item, i) => (
                <span
                  key={`${half}-${i}`}
                  className="flex items-center text-[13px] font-semibold uppercase tracking-[0.3em]"
                >
                  <span className="whitespace-nowrap">{item}</span>
                  <span className="mx-8 inline-block h-1.5 w-1.5 rotate-45 bg-blanc/70" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* ————— 3.2 PRÉSENTATION ÉCLAIR ————— */}
      <section className="bg-blanc py-24 md:py-32">
        <div className="container-site grid items-center gap-16 lg:grid-cols-2 lg:gap-24">
          <div>
            <SectionHeading
              align="left"
              kicker="Un homme hors du commun"
              title="La Force du Buffle au Service de Votre Destinée"
            />
            <blockquote
              data-reveal
              className="mt-9 rounded-r-2xl border-l-4 border-rouge bg-gris p-7 md:p-8"
            >
              <Quote className="h-6 w-6 text-rouge" aria-hidden="true" />
              <p className="mt-4 text-[17px] font-semibold italic leading-relaxed text-noir md:text-xl">
                « Comme le buffle qui traverse la savane et la forêt dense sans jamais dévier de sa
                trajectoire, l’homme guidé par la puissance de ses ancêtres ne recule devant aucun
                obstacle. »
              </p>
            </blockquote>
            <div data-reveal data-delay="0.1" className="mt-8 space-y-5 text-[15px] leading-relaxed text-neutral-600 md:text-base">
              <p>
                Fils de Dah MÊTONOU et de Madame Ayiountchi HOUANDOSSI, Dah SONON-BITI a grandi sous
                le signe du sacré, initié très tôt aux enseignements des couvents traditionnels du
                Bénin. Ancien infirmier au sein de la Société Lion d’Or Bénin, il a fait de la
                complémentarité entre médecine moderne et pharmacopée africaine une signature rare.
              </p>
              <p>
                Reconnu Prêtre de Fâ Oroumila, médium et guérisseur traditionnel, il est aussi le
                président-fondateur de l’ONG Savoir Vivre Bénin — une autorité traditionnelle dont
                la parole éclaire et dont l’action transforme.
              </p>
            </div>
            <ul data-reveal data-delay="0.14" className="mt-9 space-y-1.5">
              {KEY_FACTS.map((fact) => (
                <li
                  key={fact.title}
                  className="group flex items-center gap-4 rounded-2xl px-3 py-3 transition-colors duration-300 hover:bg-gris"
                >
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-rouge/[0.06] text-rouge transition-colors duration-300 group-hover:bg-rouge group-hover:text-blanc">
                    {fact.icon}
                  </span>
                  <span className="leading-tight">
                    <span className="block text-sm font-semibold tracking-tight text-noir">
                      {fact.title}
                    </span>
                    <span className="mt-0.5 block text-[13px] text-neutral-500">{fact.sub}</span>
                  </span>
                </li>
              ))}
            </ul>
            <div data-reveal data-delay="0.18" className="mt-9">
              <Link to="/biographie" className="btn-dark">
                Lire sa biographie complète
                <ArrowRight className="h-4.5 w-4.5" />
              </Link>
            </div>
          </div>

          <div data-reveal className="relative mx-auto w-full max-w-md lg:max-w-none">
            <div
              className="absolute inset-0 translate-x-4 translate-y-4 rounded-3xl border-2 border-rouge/60 md:translate-x-6 md:translate-y-6"
              aria-hidden="true"
            />
            <BuffaloMark
              className="absolute -right-10 -top-10 hidden h-28 w-28 text-noir/[0.07] lg:block"
              accent="currentColor"
            />
            <img
              src={PORTRAIT_IMG}
              alt="Sa Majesté Dah SONON-BITI « Le Buffle », Prêtre de Fâ Oroumila"
              className="relative h-auto w-full rounded-3xl"
              loading="lazy"
            />
            <div className="absolute -bottom-6 left-6 flex items-center gap-3.5 rounded-2xl bg-noir px-5 py-4 text-blanc shadow-xl md:left-8">
              <BuffaloMark className="h-9 w-9" accent="#B01F24" />
              <div className="leading-tight">
                <p className="text-[13px] font-semibold">Prêtre de Fâ Oroumila</p>
                <p className="text-[11px] text-blanc/55">Abomey-Calavi · Bénin</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ————— 3.3 LES 4 SERVICES PHARES ————— */}
      <section className="bg-gris py-24 md:py-32">
        <div className="container-site">
          <SectionHeading
            kicker="Nos domaines d’intervention"
            title="Des Solutions Puissantes et Éprouvées pour Chaque Aspect de Votre Vie"
            description="Quatre territoires d’action, une même exigence : des résultats concrets, obtenus dans le respect des enseignements des ancêtres."
          />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:mt-16 lg:grid-cols-2">
            {SERVICES.map((service, i) => (
              <InfoCard
                key={service.title}
                icon={service.icon}
                title={service.title}
                description={service.description}
                linkText={service.linkText}
                linkTo="/contact"
                delay={i * 0.08}
                tone="light"
              />
            ))}
          </div>
        </div>
      </section>

      {/* ————— 3.4 POURQUOI CHOISIR DAH SONON-BITI ————— */}
      <section className="bg-blanc py-24 md:py-32">
        <div className="container-site">
          <SectionHeading
            kicker="Une autorité. Un engagement."
            title="Ce qui fait de lui un guide spirituel hors pair."
            align="left"
          />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:mt-16 lg:grid-cols-3">
            {STRENGTHS.map((strength, i) => (
              <div
                key={strength.title}
                data-reveal
                data-delay={String(i * 0.05)}
                className="flex flex-col items-start rounded-2xl bg-blanc border border-neutral-100 p-8 shadow-[0_2px_12px_rgba(10,10,10,0.04)]"
              >
                <div className="mb-6 flex h-10 w-10 items-center justify-center rounded-lg bg-rouge/5 text-rouge">
                  {strength.icon}
                </div>
                <h3 className="mb-3 text-[18px] font-bold tracking-tight text-noir">{strength.title}</h3>
                <p className="mb-6 text-[15px] leading-relaxed text-neutral-500">{strength.description}</p>
                <Link to="/biographie" className="flex items-center gap-2 text-[13px] font-bold uppercase tracking-widest text-rouge transition-transform hover:translate-x-1">
                  En savoir plus <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ————— 3.5 TÉMOIGNAGES ————— */}
      <section id="temoignages" className="bg-[#fcfcfc] py-24 md:py-32 border-t border-neutral-100">
        <div className="container-site">
          <SectionHeading
            kicker="Paroles de reconnaissance"
            title="La confiance se raconte avec des mots vrais."
            description="Les témoignages seront présentés ici après réception des citations originales et de l'accord des personnes concernées."
            align="left"
          />
        </div>
      </section>

      {/* ————— 3.6 CTA FINAL ————— */}
      <section className="bg-noir py-24 md:py-32">
        <div className="container-site">
          <span data-reveal className="text-rouge text-[13px] font-bold uppercase tracking-widest">
            Votre chemin commence par un échange
          </span>
          <h2
            data-reveal
            data-delay="0.08"
            className="mt-8 text-4xl font-bold leading-[1.1] tracking-tight text-blanc md:text-[3.5rem] lg:text-[4rem]"
          >
            Le moment de transformer votre vie, <br />
            c’est maintenant.
          </h2>
          <p
            data-reveal
            data-delay="0.16"
            className="mt-8 max-w-2xl text-[17px] leading-relaxed text-blanc/60 md:text-xl"
          >
            Une écoute attentive, une tradition vivante et un accompagnement respectueux de votre situation. Faites le premier pas, en toute discrétion.
          </p>
          <div data-reveal data-delay="0.24" className="mt-12 flex flex-wrap items-center gap-4">
            <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="btn-primary">
              Discuter sur WhatsApp
              <WhatsAppIcon className="h-4.5 w-4.5" />
            </a>
            <Link to="/contact" className="px-6 py-4 rounded-lg border border-blanc/20 text-blanc text-[15px] font-bold hover:bg-blanc hover:text-noir transition-all">
              Réserver une consultation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
