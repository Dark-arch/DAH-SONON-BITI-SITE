import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { LenisProvider } from "./context/LenisContext";
import ScrollManager from "./components/ScrollManager";
import Header from "./components/Header";
import Footer from "./components/Footer";
import FloatingWhatsApp from "./components/FloatingWhatsApp";
import Home from "./pages/Home";
import Biographie from "./pages/Biographie";
import MissionVision from "./pages/MissionVision";
import Domaines from "./pages/Domaines";
import Contact from "./pages/Contact";

export default function App() {
  return (
    <BrowserRouter>
      <LenisProvider>
        <ScrollManager />
        <div className="min-h-screen bg-blanc font-sans text-noir">
          <Header />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/biographie" element={<Biographie />} />
              <Route path="/mission-vision" element={<MissionVision />} />
              <Route path="/domaines" element={<Domaines />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
          <Footer />
          <FloatingWhatsApp />
        </div>
      </LenisProvider>
    </BrowserRouter>
  );
}
