import { useEffect, useRef } from "react";
import { gsap, useGSAP, ScrollTrigger } from "../lib/gsap";

/**
 * Reveal animations for a page scope.
 * - `[data-hero]` elements animate on mount (value = delay in seconds).
 * - `[data-reveal]` elements animate on scroll into view (data-delay = delay in seconds).
 */
export function useReveal<T extends HTMLElement = HTMLDivElement>() {
  const scope = useRef<T | null>(null);

  useGSAP(
    () => {
      const heroEls = gsap.utils.toArray<HTMLElement>("[data-hero]", scope.current);
      if (heroEls.length) {
        gsap.set(heroEls, { y: 30, opacity: 0 });
        heroEls.forEach((el) => {
          gsap.to(el, {
            y: 0,
            opacity: 1,
            duration: 1.05,
            ease: "power3.out",
            delay: parseFloat(el.dataset.hero || "0"),
          });
        });
      }

      const revealEls = gsap.utils.toArray<HTMLElement>("[data-reveal]", scope.current);
      revealEls.forEach((el) => {
        gsap.fromTo(
          el,
          { y: 28, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.95,
            ease: "power3.out",
            delay: parseFloat(el.dataset.delay || "0"),
            scrollTrigger: { trigger: el, start: "top 90%", once: true },
          }
        );
      });

      ScrollTrigger.refresh();
    },
    { scope }
  );

  return scope;
}

export function useTitle(title: string) {
  useEffect(() => {
    document.title = title;
  }, [title]);
}
